﻿namespace Project
{
    partial class Rooms
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRoom2 = new System.Windows.Forms.Button();
            this.btnRoom3 = new System.Windows.Forms.Button();
            this.btnRoom1 = new System.Windows.Forms.Button();
            this.btnRoom4 = new System.Windows.Forms.Button();
            this.pnlRoom1 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.btnBed3_R1 = new System.Windows.Forms.Button();
            this.btnBed5_R1 = new System.Windows.Forms.Button();
            this.btnBed4_R1 = new System.Windows.Forms.Button();
            this.btnBed2_R1 = new System.Windows.Forms.Button();
            this.btnBed6_R1 = new System.Windows.Forms.Button();
            this.btnBed7_R1 = new System.Windows.Forms.Button();
            this.btnBed8_R1 = new System.Windows.Forms.Button();
            this.btnBed1_R1 = new System.Windows.Forms.Button();
            this.pnlRoom2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnBed3_R2 = new System.Windows.Forms.Button();
            this.btnBed5_R2 = new System.Windows.Forms.Button();
            this.btnBed4_R2 = new System.Windows.Forms.Button();
            this.btnBed2_R2 = new System.Windows.Forms.Button();
            this.btnBed6_R2 = new System.Windows.Forms.Button();
            this.btnBed7_R2 = new System.Windows.Forms.Button();
            this.btnBed8_R2 = new System.Windows.Forms.Button();
            this.btnBed1_R2 = new System.Windows.Forms.Button();
            this.pnlRoom3 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnBed3_R3 = new System.Windows.Forms.Button();
            this.btnBed5_R3 = new System.Windows.Forms.Button();
            this.btnBed4_R3 = new System.Windows.Forms.Button();
            this.btnBed2_R3 = new System.Windows.Forms.Button();
            this.btnBed6_R3 = new System.Windows.Forms.Button();
            this.btnBed7_R3 = new System.Windows.Forms.Button();
            this.btnBed8_R3 = new System.Windows.Forms.Button();
            this.btnBed1_R3 = new System.Windows.Forms.Button();
            this.pnlRoom4 = new System.Windows.Forms.Panel();
            this.lblBed8_R4 = new System.Windows.Forms.Label();
            this.lblBed7_R4 = new System.Windows.Forms.Label();
            this.lblBed6_R4 = new System.Windows.Forms.Label();
            this.lblBed5_R4 = new System.Windows.Forms.Label();
            this.lblBed4_R4 = new System.Windows.Forms.Label();
            this.lblBed3_R4 = new System.Windows.Forms.Label();
            this.lblBed2_R4 = new System.Windows.Forms.Label();
            this.lblBed1_R4 = new System.Windows.Forms.Label();
            this.btnBed3_R4 = new System.Windows.Forms.Button();
            this.btnBed5_R4 = new System.Windows.Forms.Button();
            this.btnBed4_R4 = new System.Windows.Forms.Button();
            this.btnBed2_R4 = new System.Windows.Forms.Button();
            this.btnBed6_R4 = new System.Windows.Forms.Button();
            this.btnBed7_R4 = new System.Windows.Forms.Button();
            this.btnBed8_R4 = new System.Windows.Forms.Button();
            this.btnBed1_R4 = new System.Windows.Forms.Button();
            this.SidePanel2 = new System.Windows.Forms.Panel();
            this.pnlRoom1.SuspendLayout();
            this.pnlRoom2.SuspendLayout();
            this.pnlRoom3.SuspendLayout();
            this.pnlRoom4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRoom2
            // 
            this.btnRoom2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRoom2.Location = new System.Drawing.Point(15, 261);
            this.btnRoom2.Name = "btnRoom2";
            this.btnRoom2.Size = new System.Drawing.Size(156, 45);
            this.btnRoom2.TabIndex = 1;
            this.btnRoom2.Text = "Room Number 2";
            this.btnRoom2.UseVisualStyleBackColor = false;
            this.btnRoom2.Click += new System.EventHandler(this.btnRoom2_Click);
            // 
            // btnRoom3
            // 
            this.btnRoom3.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRoom3.Location = new System.Drawing.Point(15, 304);
            this.btnRoom3.Name = "btnRoom3";
            this.btnRoom3.Size = new System.Drawing.Size(156, 45);
            this.btnRoom3.TabIndex = 11;
            this.btnRoom3.Text = "Room Number 3";
            this.btnRoom3.UseVisualStyleBackColor = false;
            this.btnRoom3.Click += new System.EventHandler(this.btnRoom3_Click);
            // 
            // btnRoom1
            // 
            this.btnRoom1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRoom1.Location = new System.Drawing.Point(15, 217);
            this.btnRoom1.Name = "btnRoom1";
            this.btnRoom1.Size = new System.Drawing.Size(156, 45);
            this.btnRoom1.TabIndex = 13;
            this.btnRoom1.Text = "Room Number 1";
            this.btnRoom1.UseVisualStyleBackColor = false;
            this.btnRoom1.Click += new System.EventHandler(this.btnRoom1_Click_1);
            // 
            // btnRoom4
            // 
            this.btnRoom4.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnRoom4.Location = new System.Drawing.Point(15, 350);
            this.btnRoom4.Name = "btnRoom4";
            this.btnRoom4.Size = new System.Drawing.Size(156, 45);
            this.btnRoom4.TabIndex = 14;
            this.btnRoom4.Text = "Room Number 4";
            this.btnRoom4.UseVisualStyleBackColor = false;
            this.btnRoom4.Click += new System.EventHandler(this.btnRoom4_Click);
            // 
            // pnlRoom1
            // 
            this.pnlRoom1.Controls.Add(this.label17);
            this.pnlRoom1.Controls.Add(this.label18);
            this.pnlRoom1.Controls.Add(this.label19);
            this.pnlRoom1.Controls.Add(this.label20);
            this.pnlRoom1.Controls.Add(this.label21);
            this.pnlRoom1.Controls.Add(this.label22);
            this.pnlRoom1.Controls.Add(this.label23);
            this.pnlRoom1.Controls.Add(this.label24);
            this.pnlRoom1.Controls.Add(this.btnBed3_R1);
            this.pnlRoom1.Controls.Add(this.btnBed5_R1);
            this.pnlRoom1.Controls.Add(this.btnBed4_R1);
            this.pnlRoom1.Controls.Add(this.btnBed2_R1);
            this.pnlRoom1.Controls.Add(this.btnBed6_R1);
            this.pnlRoom1.Controls.Add(this.btnBed7_R1);
            this.pnlRoom1.Controls.Add(this.btnBed8_R1);
            this.pnlRoom1.Controls.Add(this.btnBed1_R1);
            this.pnlRoom1.Location = new System.Drawing.Point(240, 62);
            this.pnlRoom1.Name = "pnlRoom1";
            this.pnlRoom1.Size = new System.Drawing.Size(1160, 568);
            this.pnlRoom1.TabIndex = 18;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(839, 296);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(18, 20);
            this.label17.TabIndex = 59;
            this.label17.Text = "8";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Location = new System.Drawing.Point(599, 296);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(18, 20);
            this.label18.TabIndex = 58;
            this.label18.Text = "7";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(363, 295);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 20);
            this.label19.TabIndex = 57;
            this.label19.Text = "6";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Location = new System.Drawing.Point(127, 294);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(18, 20);
            this.label20.TabIndex = 56;
            this.label20.Text = "5";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Location = new System.Drawing.Point(836, 60);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(18, 20);
            this.label21.TabIndex = 55;
            this.label21.Text = "4";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(599, 59);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(18, 20);
            this.label22.TabIndex = 54;
            this.label22.Text = "3";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(365, 59);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(18, 20);
            this.label23.TabIndex = 53;
            this.label23.Text = "2";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(128, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(18, 20);
            this.label24.TabIndex = 52;
            this.label24.Text = "1";
            // 
            // btnBed3_R1
            // 
            this.btnBed3_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed3_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed3_R1.Location = new System.Drawing.Point(620, 54);
            this.btnBed3_R1.Name = "btnBed3_R1";
            this.btnBed3_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed3_R1.TabIndex = 51;
            this.btnBed3_R1.Text = "Bed Number 3";
            this.btnBed3_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed3_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed5_R1
            // 
            this.btnBed5_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed5_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed5_R1.Location = new System.Drawing.Point(149, 290);
            this.btnBed5_R1.Name = "btnBed5_R1";
            this.btnBed5_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed5_R1.TabIndex = 50;
            this.btnBed5_R1.Text = "Bed Number 5";
            this.btnBed5_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed5_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed4_R1
            // 
            this.btnBed4_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed4_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed4_R1.Location = new System.Drawing.Point(859, 54);
            this.btnBed4_R1.Name = "btnBed4_R1";
            this.btnBed4_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed4_R1.TabIndex = 49;
            this.btnBed4_R1.Text = "Bed Number 4";
            this.btnBed4_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed4_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed2_R1
            // 
            this.btnBed2_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed2_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed2_R1.Location = new System.Drawing.Point(384, 53);
            this.btnBed2_R1.Name = "btnBed2_R1";
            this.btnBed2_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed2_R1.TabIndex = 48;
            this.btnBed2_R1.Text = "Bed Number 2";
            this.btnBed2_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed2_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed6_R1
            // 
            this.btnBed6_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed6_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed6_R1.Location = new System.Drawing.Point(384, 290);
            this.btnBed6_R1.Name = "btnBed6_R1";
            this.btnBed6_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed6_R1.TabIndex = 47;
            this.btnBed6_R1.Text = "Bed Number 6";
            this.btnBed6_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed6_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed7_R1
            // 
            this.btnBed7_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed7_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed7_R1.Location = new System.Drawing.Point(622, 290);
            this.btnBed7_R1.Name = "btnBed7_R1";
            this.btnBed7_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed7_R1.TabIndex = 46;
            this.btnBed7_R1.Text = "Bed Number 7";
            this.btnBed7_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed7_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed8_R1
            // 
            this.btnBed8_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed8_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed8_R1.Location = new System.Drawing.Point(859, 290);
            this.btnBed8_R1.Name = "btnBed8_R1";
            this.btnBed8_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed8_R1.TabIndex = 45;
            this.btnBed8_R1.Text = "Bed Number 8";
            this.btnBed8_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed8_R1.UseVisualStyleBackColor = false;
            // 
            // btnBed1_R1
            // 
            this.btnBed1_R1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed1_R1.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed1_R1.Location = new System.Drawing.Point(149, 54);
            this.btnBed1_R1.Name = "btnBed1_R1";
            this.btnBed1_R1.Size = new System.Drawing.Size(174, 226);
            this.btnBed1_R1.TabIndex = 44;
            this.btnBed1_R1.Text = "Bed Number 1";
            this.btnBed1_R1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed1_R1.UseVisualStyleBackColor = false;
            // 
            // pnlRoom2
            // 
            this.pnlRoom2.Controls.Add(this.label1);
            this.pnlRoom2.Controls.Add(this.label2);
            this.pnlRoom2.Controls.Add(this.label3);
            this.pnlRoom2.Controls.Add(this.label4);
            this.pnlRoom2.Controls.Add(this.label5);
            this.pnlRoom2.Controls.Add(this.label6);
            this.pnlRoom2.Controls.Add(this.label7);
            this.pnlRoom2.Controls.Add(this.label8);
            this.pnlRoom2.Controls.Add(this.btnBed3_R2);
            this.pnlRoom2.Controls.Add(this.btnBed5_R2);
            this.pnlRoom2.Controls.Add(this.btnBed4_R2);
            this.pnlRoom2.Controls.Add(this.btnBed2_R2);
            this.pnlRoom2.Controls.Add(this.btnBed6_R2);
            this.pnlRoom2.Controls.Add(this.btnBed7_R2);
            this.pnlRoom2.Controls.Add(this.btnBed8_R2);
            this.pnlRoom2.Controls.Add(this.btnBed1_R2);
            this.pnlRoom2.Location = new System.Drawing.Point(240, 62);
            this.pnlRoom2.Name = "pnlRoom2";
            this.pnlRoom2.Size = new System.Drawing.Size(1160, 568);
            this.pnlRoom2.TabIndex = 43;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(839, 296);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 20);
            this.label1.TabIndex = 91;
            this.label1.Text = "8";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(599, 296);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 90;
            this.label2.Text = "7";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(363, 295);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 89;
            this.label3.Text = "6";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(127, 294);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 88;
            this.label4.Text = "5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Location = new System.Drawing.Point(836, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 87;
            this.label5.Text = "4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(599, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(18, 20);
            this.label6.TabIndex = 86;
            this.label6.Text = "3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(365, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 20);
            this.label7.TabIndex = 85;
            this.label7.Text = "2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(128, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(18, 20);
            this.label8.TabIndex = 84;
            this.label8.Text = "1";
            // 
            // btnBed3_R2
            // 
            this.btnBed3_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed3_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed3_R2.Location = new System.Drawing.Point(620, 54);
            this.btnBed3_R2.Name = "btnBed3_R2";
            this.btnBed3_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed3_R2.TabIndex = 83;
            this.btnBed3_R2.Text = "Bed Number 3";
            this.btnBed3_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed3_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed5_R2
            // 
            this.btnBed5_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed5_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed5_R2.Location = new System.Drawing.Point(149, 290);
            this.btnBed5_R2.Name = "btnBed5_R2";
            this.btnBed5_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed5_R2.TabIndex = 82;
            this.btnBed5_R2.Text = "Bed Number 5";
            this.btnBed5_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed5_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed4_R2
            // 
            this.btnBed4_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed4_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed4_R2.Location = new System.Drawing.Point(859, 54);
            this.btnBed4_R2.Name = "btnBed4_R2";
            this.btnBed4_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed4_R2.TabIndex = 81;
            this.btnBed4_R2.Text = "Bed Number 4";
            this.btnBed4_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed4_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed2_R2
            // 
            this.btnBed2_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed2_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed2_R2.Location = new System.Drawing.Point(384, 53);
            this.btnBed2_R2.Name = "btnBed2_R2";
            this.btnBed2_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed2_R2.TabIndex = 80;
            this.btnBed2_R2.Text = "Bed Number 2";
            this.btnBed2_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed2_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed6_R2
            // 
            this.btnBed6_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed6_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed6_R2.Location = new System.Drawing.Point(384, 290);
            this.btnBed6_R2.Name = "btnBed6_R2";
            this.btnBed6_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed6_R2.TabIndex = 79;
            this.btnBed6_R2.Text = "Bed Number 6";
            this.btnBed6_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed6_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed7_R2
            // 
            this.btnBed7_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed7_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed7_R2.Location = new System.Drawing.Point(622, 290);
            this.btnBed7_R2.Name = "btnBed7_R2";
            this.btnBed7_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed7_R2.TabIndex = 78;
            this.btnBed7_R2.Text = "Bed Number 7";
            this.btnBed7_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed7_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed8_R2
            // 
            this.btnBed8_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed8_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed8_R2.Location = new System.Drawing.Point(859, 290);
            this.btnBed8_R2.Name = "btnBed8_R2";
            this.btnBed8_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed8_R2.TabIndex = 77;
            this.btnBed8_R2.Text = "Bed Number 8";
            this.btnBed8_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed8_R2.UseVisualStyleBackColor = false;
            // 
            // btnBed1_R2
            // 
            this.btnBed1_R2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed1_R2.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed1_R2.Location = new System.Drawing.Point(149, 54);
            this.btnBed1_R2.Name = "btnBed1_R2";
            this.btnBed1_R2.Size = new System.Drawing.Size(174, 226);
            this.btnBed1_R2.TabIndex = 76;
            this.btnBed1_R2.Text = "Bed Number 1";
            this.btnBed1_R2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed1_R2.UseVisualStyleBackColor = false;
            // 
            // pnlRoom3
            // 
            this.pnlRoom3.Controls.Add(this.label9);
            this.pnlRoom3.Controls.Add(this.label10);
            this.pnlRoom3.Controls.Add(this.label11);
            this.pnlRoom3.Controls.Add(this.label12);
            this.pnlRoom3.Controls.Add(this.label13);
            this.pnlRoom3.Controls.Add(this.label14);
            this.pnlRoom3.Controls.Add(this.label15);
            this.pnlRoom3.Controls.Add(this.label16);
            this.pnlRoom3.Controls.Add(this.btnBed3_R3);
            this.pnlRoom3.Controls.Add(this.btnBed5_R3);
            this.pnlRoom3.Controls.Add(this.btnBed4_R3);
            this.pnlRoom3.Controls.Add(this.btnBed2_R3);
            this.pnlRoom3.Controls.Add(this.btnBed6_R3);
            this.pnlRoom3.Controls.Add(this.btnBed7_R3);
            this.pnlRoom3.Controls.Add(this.btnBed8_R3);
            this.pnlRoom3.Controls.Add(this.btnBed1_R3);
            this.pnlRoom3.Location = new System.Drawing.Point(240, 62);
            this.pnlRoom3.Name = "pnlRoom3";
            this.pnlRoom3.Size = new System.Drawing.Size(1160, 568);
            this.pnlRoom3.TabIndex = 42;
            this.pnlRoom3.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlRoom3_Paint);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(839, 296);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(18, 20);
            this.label9.TabIndex = 75;
            this.label9.Text = "8";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Location = new System.Drawing.Point(599, 296);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(18, 20);
            this.label10.TabIndex = 74;
            this.label10.Text = "7";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(363, 295);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 73;
            this.label11.Text = "6";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Location = new System.Drawing.Point(127, 294);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(18, 20);
            this.label12.TabIndex = 72;
            this.label12.Text = "5";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(836, 60);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 71;
            this.label13.Text = "4";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(599, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(18, 20);
            this.label14.TabIndex = 70;
            this.label14.Text = "3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(365, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 20);
            this.label15.TabIndex = 69;
            this.label15.Text = "2";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(128, 59);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(18, 20);
            this.label16.TabIndex = 68;
            this.label16.Text = "1";
            // 
            // btnBed3_R3
            // 
            this.btnBed3_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed3_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed3_R3.Location = new System.Drawing.Point(620, 54);
            this.btnBed3_R3.Name = "btnBed3_R3";
            this.btnBed3_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed3_R3.TabIndex = 67;
            this.btnBed3_R3.Text = "Bed Number 3";
            this.btnBed3_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed3_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed5_R3
            // 
            this.btnBed5_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed5_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed5_R3.Location = new System.Drawing.Point(149, 290);
            this.btnBed5_R3.Name = "btnBed5_R3";
            this.btnBed5_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed5_R3.TabIndex = 66;
            this.btnBed5_R3.Text = "Bed Number 5";
            this.btnBed5_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed5_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed4_R3
            // 
            this.btnBed4_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed4_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed4_R3.Location = new System.Drawing.Point(859, 54);
            this.btnBed4_R3.Name = "btnBed4_R3";
            this.btnBed4_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed4_R3.TabIndex = 65;
            this.btnBed4_R3.Text = "Bed Number 4";
            this.btnBed4_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed4_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed2_R3
            // 
            this.btnBed2_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed2_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed2_R3.Location = new System.Drawing.Point(384, 53);
            this.btnBed2_R3.Name = "btnBed2_R3";
            this.btnBed2_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed2_R3.TabIndex = 64;
            this.btnBed2_R3.Text = "Bed Number 2";
            this.btnBed2_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed2_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed6_R3
            // 
            this.btnBed6_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed6_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed6_R3.Location = new System.Drawing.Point(384, 290);
            this.btnBed6_R3.Name = "btnBed6_R3";
            this.btnBed6_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed6_R3.TabIndex = 63;
            this.btnBed6_R3.Text = "Bed Number 6";
            this.btnBed6_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed6_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed7_R3
            // 
            this.btnBed7_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed7_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed7_R3.Location = new System.Drawing.Point(622, 290);
            this.btnBed7_R3.Name = "btnBed7_R3";
            this.btnBed7_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed7_R3.TabIndex = 62;
            this.btnBed7_R3.Text = "Bed Number 7";
            this.btnBed7_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed7_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed8_R3
            // 
            this.btnBed8_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed8_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed8_R3.Location = new System.Drawing.Point(859, 290);
            this.btnBed8_R3.Name = "btnBed8_R3";
            this.btnBed8_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed8_R3.TabIndex = 61;
            this.btnBed8_R3.Text = "Bed Number 8";
            this.btnBed8_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed8_R3.UseVisualStyleBackColor = false;
            // 
            // btnBed1_R3
            // 
            this.btnBed1_R3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed1_R3.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed1_R3.Location = new System.Drawing.Point(149, 54);
            this.btnBed1_R3.Name = "btnBed1_R3";
            this.btnBed1_R3.Size = new System.Drawing.Size(174, 226);
            this.btnBed1_R3.TabIndex = 60;
            this.btnBed1_R3.Text = "Bed Number 1";
            this.btnBed1_R3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed1_R3.UseVisualStyleBackColor = false;
            // 
            // pnlRoom4
            // 
            this.pnlRoom4.Controls.Add(this.lblBed8_R4);
            this.pnlRoom4.Controls.Add(this.lblBed7_R4);
            this.pnlRoom4.Controls.Add(this.lblBed6_R4);
            this.pnlRoom4.Controls.Add(this.lblBed5_R4);
            this.pnlRoom4.Controls.Add(this.lblBed4_R4);
            this.pnlRoom4.Controls.Add(this.lblBed3_R4);
            this.pnlRoom4.Controls.Add(this.lblBed2_R4);
            this.pnlRoom4.Controls.Add(this.lblBed1_R4);
            this.pnlRoom4.Controls.Add(this.btnBed3_R4);
            this.pnlRoom4.Controls.Add(this.btnBed5_R4);
            this.pnlRoom4.Controls.Add(this.btnBed4_R4);
            this.pnlRoom4.Controls.Add(this.btnBed2_R4);
            this.pnlRoom4.Controls.Add(this.btnBed6_R4);
            this.pnlRoom4.Controls.Add(this.btnBed7_R4);
            this.pnlRoom4.Controls.Add(this.btnBed8_R4);
            this.pnlRoom4.Controls.Add(this.btnBed1_R4);
            this.pnlRoom4.Location = new System.Drawing.Point(240, 62);
            this.pnlRoom4.Name = "pnlRoom4";
            this.pnlRoom4.Size = new System.Drawing.Size(1160, 568);
            this.pnlRoom4.TabIndex = 43;
            this.pnlRoom4.Visible = false;
            this.pnlRoom4.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlRoom4_Paint);
            // 
            // lblBed8_R4
            // 
            this.lblBed8_R4.AutoSize = true;
            this.lblBed8_R4.BackColor = System.Drawing.Color.White;
            this.lblBed8_R4.Location = new System.Drawing.Point(828, 295);
            this.lblBed8_R4.Name = "lblBed8_R4";
            this.lblBed8_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed8_R4.TabIndex = 41;
            this.lblBed8_R4.Text = "8";
            // 
            // lblBed7_R4
            // 
            this.lblBed7_R4.AutoSize = true;
            this.lblBed7_R4.BackColor = System.Drawing.Color.Transparent;
            this.lblBed7_R4.Location = new System.Drawing.Point(588, 295);
            this.lblBed7_R4.Name = "lblBed7_R4";
            this.lblBed7_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed7_R4.TabIndex = 40;
            this.lblBed7_R4.Text = "7";
            // 
            // lblBed6_R4
            // 
            this.lblBed6_R4.AutoSize = true;
            this.lblBed6_R4.BackColor = System.Drawing.Color.White;
            this.lblBed6_R4.Location = new System.Drawing.Point(352, 294);
            this.lblBed6_R4.Name = "lblBed6_R4";
            this.lblBed6_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed6_R4.TabIndex = 39;
            this.lblBed6_R4.Text = "6";
            // 
            // lblBed5_R4
            // 
            this.lblBed5_R4.AutoSize = true;
            this.lblBed5_R4.BackColor = System.Drawing.Color.Transparent;
            this.lblBed5_R4.Location = new System.Drawing.Point(116, 293);
            this.lblBed5_R4.Name = "lblBed5_R4";
            this.lblBed5_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed5_R4.TabIndex = 38;
            this.lblBed5_R4.Text = "5";
            // 
            // lblBed4_R4
            // 
            this.lblBed4_R4.AutoSize = true;
            this.lblBed4_R4.BackColor = System.Drawing.Color.Transparent;
            this.lblBed4_R4.Location = new System.Drawing.Point(825, 59);
            this.lblBed4_R4.Name = "lblBed4_R4";
            this.lblBed4_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed4_R4.TabIndex = 37;
            this.lblBed4_R4.Text = "4";
            // 
            // lblBed3_R4
            // 
            this.lblBed3_R4.AutoSize = true;
            this.lblBed3_R4.BackColor = System.Drawing.Color.White;
            this.lblBed3_R4.Location = new System.Drawing.Point(588, 58);
            this.lblBed3_R4.Name = "lblBed3_R4";
            this.lblBed3_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed3_R4.TabIndex = 36;
            this.lblBed3_R4.Text = "3";
            // 
            // lblBed2_R4
            // 
            this.lblBed2_R4.AutoSize = true;
            this.lblBed2_R4.BackColor = System.Drawing.Color.White;
            this.lblBed2_R4.Location = new System.Drawing.Point(354, 58);
            this.lblBed2_R4.Name = "lblBed2_R4";
            this.lblBed2_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed2_R4.TabIndex = 35;
            this.lblBed2_R4.Text = "2";
            // 
            // lblBed1_R4
            // 
            this.lblBed1_R4.AutoSize = true;
            this.lblBed1_R4.BackColor = System.Drawing.Color.White;
            this.lblBed1_R4.Location = new System.Drawing.Point(117, 58);
            this.lblBed1_R4.Name = "lblBed1_R4";
            this.lblBed1_R4.Size = new System.Drawing.Size(18, 20);
            this.lblBed1_R4.TabIndex = 34;
            this.lblBed1_R4.Text = "1";
            // 
            // btnBed3_R4
            // 
            this.btnBed3_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed3_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed3_R4.Location = new System.Drawing.Point(609, 53);
            this.btnBed3_R4.Name = "btnBed3_R4";
            this.btnBed3_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed3_R4.TabIndex = 33;
            this.btnBed3_R4.Text = "Bed Number 3";
            this.btnBed3_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed3_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed5_R4
            // 
            this.btnBed5_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed5_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed5_R4.Location = new System.Drawing.Point(138, 289);
            this.btnBed5_R4.Name = "btnBed5_R4";
            this.btnBed5_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed5_R4.TabIndex = 32;
            this.btnBed5_R4.Text = "Bed Number 5";
            this.btnBed5_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed5_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed4_R4
            // 
            this.btnBed4_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed4_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed4_R4.Location = new System.Drawing.Point(848, 53);
            this.btnBed4_R4.Name = "btnBed4_R4";
            this.btnBed4_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed4_R4.TabIndex = 31;
            this.btnBed4_R4.Text = "Bed Number 4";
            this.btnBed4_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed4_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed2_R4
            // 
            this.btnBed2_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed2_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed2_R4.Location = new System.Drawing.Point(373, 52);
            this.btnBed2_R4.Name = "btnBed2_R4";
            this.btnBed2_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed2_R4.TabIndex = 30;
            this.btnBed2_R4.Text = "Bed Number 2";
            this.btnBed2_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed2_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed6_R4
            // 
            this.btnBed6_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed6_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed6_R4.Location = new System.Drawing.Point(373, 289);
            this.btnBed6_R4.Name = "btnBed6_R4";
            this.btnBed6_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed6_R4.TabIndex = 29;
            this.btnBed6_R4.Text = "Bed Number 6";
            this.btnBed6_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed6_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed7_R4
            // 
            this.btnBed7_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed7_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed7_R4.Location = new System.Drawing.Point(611, 289);
            this.btnBed7_R4.Name = "btnBed7_R4";
            this.btnBed7_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed7_R4.TabIndex = 28;
            this.btnBed7_R4.Text = "Bed Number 7";
            this.btnBed7_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed7_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed8_R4
            // 
            this.btnBed8_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed8_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed8_R4.Location = new System.Drawing.Point(848, 289);
            this.btnBed8_R4.Name = "btnBed8_R4";
            this.btnBed8_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed8_R4.TabIndex = 27;
            this.btnBed8_R4.Text = "Bed Number 8";
            this.btnBed8_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed8_R4.UseVisualStyleBackColor = false;
            // 
            // btnBed1_R4
            // 
            this.btnBed1_R4.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnBed1_R4.Image = global::Project.Properties.Resources.patient__2_;
            this.btnBed1_R4.Location = new System.Drawing.Point(138, 53);
            this.btnBed1_R4.Name = "btnBed1_R4";
            this.btnBed1_R4.Size = new System.Drawing.Size(174, 226);
            this.btnBed1_R4.TabIndex = 26;
            this.btnBed1_R4.Text = "Bed Number 1";
            this.btnBed1_R4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBed1_R4.UseVisualStyleBackColor = false;
            // 
            // SidePanel2
            // 
            this.SidePanel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.SidePanel2.Location = new System.Drawing.Point(4, 218);
            this.SidePanel2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.SidePanel2.Name = "SidePanel2";
            this.SidePanel2.Size = new System.Drawing.Size(14, 44);
            this.SidePanel2.TabIndex = 44;
            // 
            // Rooms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(144F, 144F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Controls.Add(this.pnlRoom1);
            this.Controls.Add(this.pnlRoom3);
            this.Controls.Add(this.pnlRoom2);
            this.Controls.Add(this.SidePanel2);
            this.Controls.Add(this.btnRoom4);
            this.Controls.Add(this.btnRoom1);
            this.Controls.Add(this.btnRoom3);
            this.Controls.Add(this.btnRoom2);
            this.Controls.Add(this.pnlRoom4);
            this.Name = "Rooms";
            this.Size = new System.Drawing.Size(1432, 704);
            this.pnlRoom1.ResumeLayout(false);
            this.pnlRoom1.PerformLayout();
            this.pnlRoom2.ResumeLayout(false);
            this.pnlRoom2.PerformLayout();
            this.pnlRoom3.ResumeLayout(false);
            this.pnlRoom3.PerformLayout();
            this.pnlRoom4.ResumeLayout(false);
            this.pnlRoom4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnRoom2;
        private System.Windows.Forms.Button btnRoom3;
        private System.Windows.Forms.Button btnRoom1;
        private System.Windows.Forms.Button btnRoom4;
        private System.Windows.Forms.Panel pnlRoom1;
        private System.Windows.Forms.Panel pnlRoom3;
        private System.Windows.Forms.Panel pnlRoom2;
        private System.Windows.Forms.Panel pnlRoom4;
        private System.Windows.Forms.Label lblBed8_R4;
        private System.Windows.Forms.Label lblBed7_R4;
        private System.Windows.Forms.Label lblBed6_R4;
        private System.Windows.Forms.Label lblBed5_R4;
        private System.Windows.Forms.Label lblBed4_R4;
        private System.Windows.Forms.Label lblBed3_R4;
        private System.Windows.Forms.Label lblBed2_R4;
        private System.Windows.Forms.Label lblBed1_R4;
        private System.Windows.Forms.Button btnBed3_R4;
        private System.Windows.Forms.Button btnBed5_R4;
        private System.Windows.Forms.Button btnBed4_R4;
        private System.Windows.Forms.Button btnBed2_R4;
        private System.Windows.Forms.Button btnBed6_R4;
        private System.Windows.Forms.Button btnBed7_R4;
        private System.Windows.Forms.Button btnBed8_R4;
        private System.Windows.Forms.Button btnBed1_R4;
        private System.Windows.Forms.Panel SidePanel2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btnBed3_R1;
        private System.Windows.Forms.Button btnBed5_R1;
        private System.Windows.Forms.Button btnBed4_R1;
        private System.Windows.Forms.Button btnBed2_R1;
        private System.Windows.Forms.Button btnBed6_R1;
        private System.Windows.Forms.Button btnBed7_R1;
        private System.Windows.Forms.Button btnBed8_R1;
        private System.Windows.Forms.Button btnBed1_R1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnBed3_R2;
        private System.Windows.Forms.Button btnBed5_R2;
        private System.Windows.Forms.Button btnBed4_R2;
        private System.Windows.Forms.Button btnBed2_R2;
        private System.Windows.Forms.Button btnBed6_R2;
        private System.Windows.Forms.Button btnBed7_R2;
        private System.Windows.Forms.Button btnBed8_R2;
        private System.Windows.Forms.Button btnBed1_R2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnBed3_R3;
        private System.Windows.Forms.Button btnBed5_R3;
        private System.Windows.Forms.Button btnBed4_R3;
        private System.Windows.Forms.Button btnBed2_R3;
        private System.Windows.Forms.Button btnBed6_R3;
        private System.Windows.Forms.Button btnBed7_R3;
        private System.Windows.Forms.Button btnBed8_R3;
        private System.Windows.Forms.Button btnBed1_R3;
    }
}
